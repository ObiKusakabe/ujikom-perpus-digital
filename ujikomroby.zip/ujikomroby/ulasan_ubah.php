<h1 class="mt-4">Ulasan Buku</h1>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <form method="post">
                    <?php
                    $id = $_GET['id'];
                    if (isset($_POST['submit'])) {
                        $id_buku = $_POST['id_buku'];
                        $id_user = $_SESSION['user']['userID'];
                        $ulasan = $_POST['ulasan'];
                        $rating = $_POST['rating'];
                        $query = mysqli_query($koneksi, "INSERT INTO t_ulasanbuku(userID, bukuID, ulasan, rating) VALUES ('$id_user', '$id_buku', '$ulasan', '$rating')");
                        if ($query) {
                            echo "<script>alert('Tambah Buku Berhasil')</script>";
                        } else {
                            echo "<script>alert('Tambah Buku Gagal')</script>";
                        }
                    }
                    $query = mysqli_query($koneksi, "SELECT * FROM t_ulasanbuku WHERE ulasanID=$id");
                    $data = mysqli_fetch_array($query);
                    ?>
 
                    <div class="row mb-3">
                        <div class="col-md-2">Buku</div>
                        <div class="col-md-8">
                            <select name="id_buku" class="form-control">
                                <option selected disabled>Pilih buku</option>
                                <?php
                                $buk = mysqli_query($koneksi, "SELECT * FROM t_buku");
                                while ($buku = mysqli_fetch_array($buk)) {
                                ?>
                                    <option <?php if($buku['bukuID'] == $data['bukuID']) echo 'selected'; ?> value="<?php echo $buku['bukuID']; ?>"><?php echo $buku['judul']; ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Ulasan</div>
                        <div class="col-md-8">
                        <textarea class="form-control" name="ulasan" placeholder="" id="floatingTextarea2" style="height: 100px" required><?php echo $data['ulasan']; ?></textarea>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Rating</div>
                        <div class="col-md-8">
                            <select class="form-select" name="rating">
                                <option selected disabled>Pilih rating</option>
                                <?php
                                for ($i = 1; $i <= 10; $i++) {
                                    ?>
                                    <option <?php if($data['bukuID'] == $i) echo 'selected'; ?>><?php echo $i; ?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-primary" name="submit" value="submit">Simpan</button>
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <a href="?page=buku" class="btn btn-danger">Kembali</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>